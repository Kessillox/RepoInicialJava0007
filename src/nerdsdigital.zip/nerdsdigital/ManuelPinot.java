package nerdsdigital;

public class ManuelPinot {
}
